import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Button, TextInput, AsyncStorage } from 'react-native';
import Constants from 'expo-constants';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TouchableOpacity } from 'react-native';

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>O que deseja adicionar?</Text>
      <Button
        title="Sono"
        onPress={() => navigation.navigate('Sono')}
      />
      <Button
        title="Alimentação"
        onPress={() => navigation.navigate('Alimentacao')}
      />
      <Button
        title="Exercícios"
        onPress={() => navigation.navigate('Exercicios')}
      />
    </View>
  );
}

function Sono({ navigation }) {
  const [horaDormir, setHoraDormir] = useState('');
  const [horaAcordar, setHoraAcordar] = useState('');
  const [horasDormidas, setHorasDormidas] = useState(null);

  useEffect(() => {
    recuperarHorasDormidas();
  }, []);

  const calcularHorasDormidas = () => {
    const dormir = new Date(`2023-01-01T${horaDormir}`);
    const acordar = new Date(`2023-01-01T${horaAcordar}`);

    if (acordar < dormir) {
      acordar.setDate(acordar.getDate() + 1);
    }

    const diffMs = acordar - dormir;
    const diffHrs = Math.floor((diffMs % 86400000) / 3600000);

    setHorasDormidas(diffHrs);
    salvarHorasDormidas(diffHrs);
  };

  const salvarHorasDormidas = async (horas) => {
    try {
      await AsyncStorage.setItem('horasDormidas', horas.toString());
    } catch (error) {
      console.error('Erro ao salvar horas de sono:', error);
    }
  };

  const recuperarHorasDormidas = async () => {
    try {
      const horasSalvas = await AsyncStorage.getItem('horasDormidas');
      if (horasSalvas) {
        setHorasDormidas(parseInt(horasSalvas, 10));
      }
    } catch (error) {
      console.error('Erro ao recuperar horas de sono:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Veja quantas horas dormiu:</Text>

      <TextInput
        style={styles.input}
        placeholder="Horas que foi dormir (HH:mm)"
       // keyboardType="numeric"
        value={horaDormir}
        onChangeText={(text) => setHoraDormir(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Hora que acordou: (HH:mm)"
      //  keyboardType="numeric"
        value={horaAcordar}
        onChangeText={(text) => setHoraAcordar(text)}
      />

      <Button title="Calcular Horas de Sono" onPress={calcularHorasDormidas} />

      {horasDormidas !== null && (
        <Text style={styles.result}>
          Você dormiu por {horasDormidas} horas.
        </Text>
      )}
    </View>
  );
}

function Alimentacao({ navigation }) {
  const [nomeAlimento, setNomeAlimento] = useState('');
  const [calorias, setCalorias] = useState('');
  const [proteinas, setProteinas] = useState('');
  const [gorduras, setGorduras] = useState('');

  const exibirValoresNutricionais = () => {
    console.log(`Alimento: ${nomeAlimento}`);
    console.log(`Calorias: ${calorias} kcal`);
    console.log(`Proteínas: ${proteinas} g`);
    console.log(`Gorduras: ${gorduras} g`);

    const dadosAlimento = {
      nomeAlimento,
      calorias,
      proteinas,
      gorduras,
    };

    AsyncStorage.setItem('dadosAlimento', JSON.stringify(dadosAlimento))
      .then(() => console.log('Informações nutricionais salvas com sucesso!'))
      .catch((error) => console.error('Erro ao salvar informações nutricionais:', error));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Registre seus alimentos</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome do Alimento"
        value={nomeAlimento}
        onChangeText={(text) => setNomeAlimento(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Calorias (kcal)"
        keyboardType="numeric"
        value={calorias}
        onChangeText={(text) => setCalorias(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Proteínas (g)"
        keyboardType="numeric"
        value={proteinas}
        onChangeText={(text) => setProteinas(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Gorduras (g)"
        keyboardType="numeric"
        value={gorduras}
        onChangeText={(text) => setGorduras(text)}
      />

      <Button title="Exibir Valores Nutricionais" onPress={exibirValoresNutricionais} />
    </View>
  );
}

function Exercicios({ navigation }) {
  const [tipoExercicio, setTipoExercicio] = useState('');
  const [repeticoes, setRepeticoes] = useState('');
  const [duracao, setDuracao] = useState('');

  const exibirDetalhesExercicio = () => {
    console.log(`Tipo de Exercício: ${tipoExercicio}`);
    console.log(`Repetições: ${repeticoes}`);
    console.log(`Duração: ${duracao} minutos`);

    const detalhesExercicio = {
      tipoExercicio,
      repeticoes,
      duracao,
    };

    AsyncStorage.setItem('detalhesExercicio', JSON.stringify(detalhesExercicio))
      .then(() => console.log('Detalhes do exercício salvos com sucesso!'))
      .catch((error) => console.error('Erro ao salvar detalhes do exercício:', error));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Registre seus exercícios</Text>

      <TextInput
        style={styles.input}
        placeholder="Tipo de Exercício"
        value={tipoExercicio}
        onChangeText={(text) => setTipoExercicio(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Repetições"
        keyboardType="numeric"
        value={repeticoes}
        onChangeText={(text) => setRepeticoes(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Duração (minutos)"
        keyboardType="numeric"
        value={duracao}
        onChangeText={(text) => setDuracao(text)}
      />

      <Button title="Exibir Detalhes do Exercício" onPress={exibirDetalhesExercicio} />
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'HabitLog' }} />
        <Stack.Screen name="Sono" component={Sono} options={{ title: 'Sono' }} />
        <Stack.Screen name="Alimentacao" component={Alimentacao} options={{ title: 'Alimentação' }} />
        <Stack.Screen name="Exercicios" component={Exercicios} options={{ title: 'Exercícios' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  result: {
    marginTop: 20,
    fontSize: 16,
    textAlign: 'center',
  },
});
